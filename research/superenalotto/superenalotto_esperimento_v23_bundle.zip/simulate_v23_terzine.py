#!/usr/bin/env python3
"""Simulate independent uniform SuperEnalotto draws and compare triple recurrence diagnostics."""
import json, numpy as np
from numba import njit
from pathlib import Path
D=Path('/mnt/data')
metrics=json.loads((D/'superenalotto_metriche_v23.json').read_text())
choose=np.zeros((91,4),dtype=np.int32)
for n in range(91):
    for k in range(1,min(n,3)+1):
        from math import comb
        choose[n,k]=comb(n,k)

@njit(cache=True)
def simulate(n_reps,n_draws,C,seed):
    np.random.seed(seed)
    ans=np.zeros((n_reps,3),dtype=np.int32)
    six=np.empty(6,dtype=np.int32)
    for rep in range(n_reps):
        counter=np.zeros(117480,dtype=np.uint8)
        unique=0;coll=0;repeatdraw=0
        for t in range(n_draws):
            for j in range(6):
                while True:
                    x=np.random.randint(1,91)
                    duplicate=False
                    for k in range(j):
                        if six[k]==x:duplicate=True;break
                    if not duplicate:break
                six[j]=x
            for j in range(1,6):
                x=six[j];k=j-1
                while k>=0 and six[k]>x:
                    six[k+1]=six[k];k-=1
                six[k+1]=x
            previous=False
            for i in range(4):
                for j in range(i+1,5):
                    for k in range(j+1,6):
                        r=C[six[i]-1,1]+C[six[j]-1,2]+C[six[k]-1,3]
                        prev=counter[r]
                        if prev==0:unique+=1
                        else:previous=True
                        coll+=prev
                        counter[r]+=1
            if previous:repeatdraw+=1
        ans[rep,0]=unique;ans[rep,1]=coll;ans[rep,2]=repeatdraw
    return ans

reps=600
sim=simulate(reps,4294,choose,172341)
obs=np.array([metrics['terzine']['distinct_triples'],
              metrics['terzine']['observed_pairs_of_triple_occurrences'],
              metrics['terzine']['draws_with_prior_triple']])
results={}
for j,key in enumerate(['terzine_distinte','collisioni_coppie','estrazioni_con_terzine_pregresse']):
    x=sim[:,j]
    z=(obs[j]-x.mean())/x.std(ddof=1)
    empirical=(1+np.count_nonzero(np.abs(x-x.mean())>=abs(obs[j]-x.mean())))/(len(x)+1)
    results[key]={'osservato':int(obs[j]),'simulazione_media':float(x.mean()),
                  'simulazione_std':float(x.std(ddof=1)),
                  'intervallo_95_pct':[float(q) for q in np.quantile(x,[.025,.975])],
                  'scarto_standardizzato':float(z),
                  'p_empirico_bilaterale':float(empirical)}
metrics['terzine']['controllo_600_simulazioni']={'n':reps,'seed':172341,'results':results}
(D/'superenalotto_metriche_v23.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2)+'\n')
import csv
with (D/'superenalotto_terzine_simulazioni_v23.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['iterazione','terzine_distinte','collisioni_coppie','estrazioni_con_terzine_pregresse'])
    for r,row in enumerate(sim,1):w.writerow([r]+row.tolist())
with (D/'superenalotto_analisi_filtri_v23.md').open('a',encoding='utf-8') as f:
    f.write('\n\n### Controllo di casualità delle terzine: 600 simulazioni indipendenti\n\n')
    f.write('Sono state simulate 600 sequenze di 4.294 estrazioni indipendenti, con 6 numeri distinti scelti uniformemente fra 1 e 90. Ogni statistica è calcolata con le stesse regole applicate allo storico. Gli intervalli sono i percentili 2,5 e 97,5 delle simulazioni.\n\n')
    f.write('| Statistica | Osservato | Media simulata | Intervallo centrale 95% | p empirico bilaterale |\n|---|---:|---:|---:|---:|\n')
    for label,key in [('Terzine distinte','terzine_distinte'),('Collisioni fra apparizioni','collisioni_coppie'),('Estrazioni con terzine pregresse','estrazioni_con_terzine_pregresse')]:
        m=results[key]
        f.write(f"| {label} | {m['osservato']:,} | {m['simulazione_media']:,.1f} | {m['intervallo_95_pct'][0]:,.0f}–{m['intervallo_95_pct'][1]:,.0f} | {m['p_empirico_bilaterale']:.3f} |\n")
    f.write('\nI p empirici qui riportati sono descrittivi/esplorativi e non sostituiscono una valutazione prospettica. Archivio: `superenalotto_terzine_simulazioni_v23.csv`; codice: `simulate_v23_terzine.py`.\n')
print(json.dumps(results,indent=2,ensure_ascii=False))
