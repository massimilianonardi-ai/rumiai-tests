// Count exactly the distinct 6-combinations ruled out by previously observed 5-subsets,
// subject to the static sorted-number F03..F08 and dynamic delay F01,F09..F14 constraints.
// Build: g++ -O3 -march=native -fopenmp -std=c++17 count_f15_v22.cpp -o count_f15_v22
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <chrono>
#include <fstream>
#include <iostream>
#include <unordered_set>
#include <vector>
#ifdef _OPENMP
#include <omp.h>
#endif
using namespace std;
struct Cand{uint8_t num[6]; uint16_t activation;};
static_assert(sizeof(Cand)==8, "packed Cand expected");
constexpr int N=4294;
constexpr int NB=91;
constexpr uint8_t LOW[6]={1,2,7,16,28,46};
constexpr uint8_t HIGH[6]={49,64,76,84,89,90};
static uint8_t num[N][6];
static uint8_t cat[N][NB];
static uint32_t ends_arr[N];
static int64_t blocked[N];
static int32_t prevsextuplesvalid[N];
inline uint64_t key6(const uint8_t *a){
    uint64_t code=0;
    for(int j=0;j<6;j++)code=(code<<7)|(uint64_t)a[j];
    return code;
}
inline bool staticvalid(const uint8_t *a){
    for(int j=0;j<6;j++)if(a[j]<LOW[j]||a[j]>HIGH[j])return false;
    return true;
}
inline bool matchcat(const uint8_t *c,const uint8_t *x){
    uint8_t a=c[x[0]],b=c[x[1]],d=c[x[2]],e=c[x[3]],f=c[x[4]],g=c[x[5]];
    // 6-item sorting network (13 comparators).
    #define SWAP(x,y) {const auto lo=std::min(x,y);const auto hi=std::max(x,y);x=lo;y=hi;}
    SWAP(a,g);SWAP(b,e);SWAP(d,f);
    SWAP(b,d);SWAP(e,f);
    SWAP(a,e);SWAP(d,g);
    SWAP(a,b);SWAP(d,e);SWAP(f,g);
    SWAP(b,d);SWAP(e,f);
    SWAP(d,e);
    #undef SWAP
    return a<=3 && b<=4 && d<=5 && e>=1 && e<=6 && f>=2 && f<=7 && g>=3 && g<=8;
}
int main(int argc,char** argv){
    const char *inpath=argc>1?argv[1]:"/mnt/data/superenalotto_numeri_v22.bin";
    const char *outpath=argc>2?argv[2]:"/mnt/data/superenalotto_f15_conteggio_v22.csv";
    ifstream in(inpath,ios::binary);
    in.read((char*)num,sizeof(num));
    if(!in || in.gcount()!=(streamsize)sizeof(num)){cerr<<"INPUT read failure\n";return 2;}
    int last[NB]; fill(last,last+NB,-1);
    uint8_t lut[10000];
    for(int delta=0;delta<10000;delta++){
        uint8_t z=9;
        if(delta==1)z=0;else if(delta<=3)z=1;else if(delta<=5)z=2;
        else if(delta<=11)z=3;else if(delta<=18)z=4;else if(delta<=26)z=5;
        else if(delta<=35)z=6;else if(delta<=53)z=7;else if(delta<=94)z=8;
        lut[delta]=z;
    }
    for(int t=0;t<N;t++){
        for(int k=1;k<NB;k++){
            int delay=t-last[k];
            cat[t][k]=(last[k]==-1||delay>94)?9:lut[delay];
        }
        for(int j=0;j<6;j++)last[num[t][j]]=t;
    }
    auto stamp=chrono::steady_clock::now();
    // The vector is in first-activation order, so each date requires checking only the
    // initial prefix that was historically known at that point.
    vector<Cand> forbidden;forbidden.reserve(2500000);
    unordered_set<uint64_t> known;known.reserve(3000000);known.max_load_factor(0.72f);
    uint64_t duplicate_count=0;
    for(int t=0;t<N;t++){
        ends_arr[t]=(uint32_t)forbidden.size();
        for(int miss=0;miss<6;miss++){
            uint8_t five[5];int k=0;
            for(int j=0;j<6;j++)if(j!=miss)five[k++]=num[t][j];
            for(int add=1;add<=90;add++){
                bool in5=false;
                for(uint8_t z:five)if(z==add){in5=true;break;}
                if(in5)continue;
                uint8_t candidate[6];k=0;bool inserted=false;
                for(int j=0;j<5;j++){
                    if(!inserted && add<five[j]){candidate[k++]=(uint8_t)add;inserted=true;}
                    candidate[k++]=five[j];
                }
                if(!inserted)candidate[k++]=(uint8_t)add;
                if(!staticvalid(candidate))continue;
                const uint64_t key=key6(candidate);
                if(known.insert(key).second){
                    Cand c;for(int j=0;j<6;j++)c.num[j]=candidate[j];
                    c.activation=(uint16_t)(t+1);
                    forbidden.push_back(c);
                } else duplicate_count++;
            }
        }
    }
    cout<<"Built candidates "<<forbidden.size()<<", duplicates "<<duplicate_count<<"; seconds "
        <<chrono::duration<double>(chrono::steady_clock::now()-stamp).count()<<"\n"<<flush;
    int test_start=68,test_end=N;
    if(argc>3){test_start=atoi(argv[3]);test_end=atoi(argv[4]);}
    if(test_start<68)test_start=68;
    if(test_end>N)test_end=N;
    auto scanstart=chrono::steady_clock::now();
    #pragma omp parallel for schedule(dynamic,16)
    for(int t=test_start;t<test_end;t++){
        const uint8_t *ct=cat[t];
        int64_t count=0;
        const uint32_t end=ends_arr[t];
        for(uint32_t k=0;k<end;k++){
            const uint8_t *x=forbidden[k].num;
            count+=matchcat(ct,x);
        }
        blocked[t]=count;
        int32_t prev=0;
        for(int s=0;s<t;s++){
            const uint8_t *x=num[s];
            if(staticvalid(x))prev+=matchcat(ct,x);
        }
        prevsextuplesvalid[t]=prev;
    }
    cout<<"Scanned "<<test_start<<".."<<test_end<<", seconds "
        <<chrono::duration<double>(chrono::steady_clock::now()-scanstart).count()<<"\n"<<flush;
    ofstream out(outpath);
    out<<"chronological_index,forbidden_sestine_passanti_F01_F03_F14,ex_F02_passanti,aggiuntive_F15_rimosse,forbidden_uniche_totali_note\n";
    for(int t=test_start;t<test_end;t++)out<<t<<","<<blocked[t]<<","<<prevsextuplesvalid[t]<<","<<blocked[t]-prevsextuplesvalid[t]<<","<<ends_arr[t]<<"\n";
}
